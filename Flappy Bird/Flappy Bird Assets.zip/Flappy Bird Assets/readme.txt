===================== Credits =====================
This graphic bundle is inspired by the video game 
"Flappy Bird" that was developed by Dong Nguyen.

Sprites in the pack were created by Megacrash.

Color palette: Endesga64.

Program: Aseprite
	 Tilesetter
==================================================

============ This bundle contain: ===============
3 player colors variations
4 backgrounds variations
24 pipes variations
12 grounds variations
==================================================

Thanks <3
				     Version 1.5